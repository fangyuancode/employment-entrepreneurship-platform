import { AppRouteRecord } from '@/types/router'

export const helpRoutes: AppRouteRecord = {
  path: '/help',
  name: 'help',

  component: '/index/index',
  meta: {
    title: 'menus.help.title',
    // <i class="ri-inbox-archive-line"></i>
    // <i class="ri-tools-line"></i>
    icon: 'ri-tools-line',
    roles: ['R_SUPER', 'R_ADMIN']
  },
  children: [

    {
      path: 'vehicle',
      name: 'vehicle',
      component: '/help/vehicle',
      meta: {
        title: 'menus.help.vehicle',
        keepAlive: false,
        fixedTab: true
      }
    },


  ]
}