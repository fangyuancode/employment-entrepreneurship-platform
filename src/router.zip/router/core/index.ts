/**
 * 路由核心模块导出
 *
 * @module router/core
 * @author AI创业助手系统 Team
 */

export { RouteRegistry } from './RouteRegistry'
export { ComponentLoader } from './ComponentLoader'
export { RouteValidator } from './RouteValidator'
export { RouteTransformer } from './RouteTransformer'
export { IframeRouteManager } from './IframeRouteManager'
export { MenuProcessor } from './MenuProcessor'
export { RoutePermissionValidator } from './RoutePermissionValidator'
